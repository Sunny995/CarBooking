import { Time } from '@angular/common';

export interface IBookings {  // check variable names
    First_Name: string;
    Last_Name: string;
    Mobile: string;
    date: Date;
    time: string;
    duration: number;
    car: string;
}
