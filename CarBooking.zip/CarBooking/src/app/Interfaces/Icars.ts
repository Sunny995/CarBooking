export interface ICars { // change name
    Name: string;
    Type: string;
    Rate: number;
    image: string;
}
