export interface ITransactions { // change name
    First_Name: string;
    Last_Name: string;
    Amount: number;
    card: string;
    }

