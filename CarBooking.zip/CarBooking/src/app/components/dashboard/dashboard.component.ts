import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BookServiceService } from '../../service/book-service.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
private userbooking = [] ;
private IfNot = true;
private IfFine = false;
private usertransaction = [] ;
private bookingDetails = [];
private usercars = [];
private car = [];
private carname: string;
private transactionDetails = [];
private user: string;
private ShowBooking = false;
private ShowTransaction = false;
private IfNotFine = false;
private IfYesFine = false;
private duration: number;
private fine: number;
private rate: number;

  constructor(private route: Router, private bookService: BookServiceService) { }

  ngOnInit(): void {
    if (sessionStorage.getItem('fname') === null) {
      this.route.navigateByUrl('home');
    } else {
    this.user = sessionStorage.getItem ('fname');
    this.carname = sessionStorage.getItem ('carname');
    this.getTransaction();
    this.getBooking();
    this.getCars();
   
    }
  }

  getTransaction(): void {
    this.bookService.getTransaction()
    .subscribe(data =>  {
         this.usertransaction = data;
         this.transactionDetails = this.usertransaction.find(c => c.firstName === this.user);
      });
  }

  getBooking(): void {
    this.bookService.getBooking()
    .subscribe(data =>  {
         this.userbooking = data;
         this.bookingDetails = this.userbooking.find(c => c.firstName === this.user);
      });
  }

  getCars(): void {
    this.bookService.getCars()
    .subscribe(data =>  {
         this.usercars = data;
         this.car = this.usercars.find(c => c.name === this.carname);
      });
  }

  booking(): void {
    if (!this.ShowBooking) {
      this.ShowBooking = true;
      } else {
        this.ShowBooking = false;
      }
  }
  transaction(): void {
    if (!this.ShowTransaction) {
      this.ShowTransaction = true;
      } else {
        this.ShowTransaction = false;
      }
  }

  delete(): void {
    this.bookService.deleteBooking(sessionStorage.getItem('fname'))
    .subscribe(data => {
    });

    this.deleteTransaction();
    this.ngOnInit();
  }

   deleteTransaction(): void {
  this.bookService.deleteTransaction(sessionStorage.getItem('fname'))
    .subscribe(data => {
      });
  sessionStorage.removeItem('fname');
    }
  logout(): void {
    sessionStorage.removeItem('fname');
    sessionStorage.removeItem('lname');

    this.route.navigateByUrl('/home');
  }

  toggle(): void {
    this.IfNot = false;
    this.IfFine = true;
  }
// change dura to something better
return(dura: number): void {

    // tslint:disable-next-line:radix
    this.duration = parseInt(sessionStorage.getItem('dura'));
// tslint:disable-next-line: radix
    this.rate = parseInt(sessionStorage.getItem('rate'));

    if (this.duration >= dura) {
      this.IfNotFine = true;
      this.IfYesFine = false;
    } else {
      this.IfNotFine = false;
      this.IfYesFine = true;
      this.fine = (this.rate * (dura - this.duration));
    }
}
}
