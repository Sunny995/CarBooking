import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CarsComponent } from './cars.component';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { HomeComponent } from '../home/home.component';
import { LoginComponent } from '../login/login.component';
import {MatCardModule} from '@angular/material/card';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import {MatToolbarModule} from '@angular/material/toolbar';
import * as Material from '@angular/material';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { AppRoutingModule } from '../../app-routing.module';
import {ReactiveFormsModule, FormsModule} from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { TransactionComponent } from '../transaction/transaction.component';
import { BookingComponent } from '../booking/booking.component';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { ICars } from 'src/app/Interfaces/Icars';

describe('CarsComponent', () => {
  let component: CarsComponent;
  let fixture: ComponentFixture<CarsComponent>;
  const mockCarsData: ICars[] = [  {
    Name: '',
    Type: '',
    Rate: 2,
    image: '',
  },
  {     Name: '',
  Type: '',
  Rate: 2,
  image: '',
  }];
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CarsComponent, BookingComponent, TransactionComponent
        , LoginComponent, HomeComponent, DashboardComponent ],
      imports : [ BrowserModule,
        AppRoutingModule,
        BrowserAnimationsModule, HttpClientModule,
         MatToolbarModule, MatButtonModule
         , MatGridListModule, ReactiveFormsModule, FormsModule, MatInputModule, MatCardModule
         , MatFormFieldModule, MatDatepickerModule, FlexLayoutModule, Material.MatNativeDateModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CarsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('BookCar is getting called', () => {

    sessionStorage.setItem('fname', 'sunny');
    component.bookCar(mockCarsData);
    sessionStorage.setItem('carname', 'swift');
    sessionStorage.setItem('rate', '20');
   });

  it('BookCar is getting called and session is null', () => {

    sessionStorage.setItem('fname', null);
    component.bookCar(mockCarsData);
    alert('please login to book');
   });


});
