import { Component, OnInit } from '@angular/core';
import { BookServiceService } from '../../service/book-service.service';
import { Router } from '@angular/router';
import { ICars } from 'src/app/Interfaces/Icars';

@Component({
  selector: 'app-cars',
  templateUrl: './cars.component.html',
  styleUrls: ['./cars.component.css']
})
export class CarsComponent implements OnInit {
private Cars = [];
constructor(private bookService: BookServiceService, private route: Router) { }

  ngOnInit(): void {
    this.bookService.getCars()
      .subscribe(data =>  {
           this.Cars = data;
        });
  }

public bookCar(p: any): void {
    if (sessionStorage.getItem('fname') != null) {
 sessionStorage.setItem('carname', p.Name);
 sessionStorage.setItem('rate', p.Rate);
 this.route.navigateByUrl('/booking');
    } else {
      alert('please login to book');
    }
  }

}
