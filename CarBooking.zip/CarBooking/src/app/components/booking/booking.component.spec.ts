import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BookingComponent } from './booking.component';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { HomeComponent } from '../home/home.component';
import { LoginComponent } from '../login/login.component';
import {MatCardModule} from '@angular/material/card';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import {MatToolbarModule} from '@angular/material/toolbar';
import * as Material from '@angular/material';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { AppRoutingModule } from '../../app-routing.module';
import {ReactiveFormsModule, FormsModule} from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { TransactionComponent } from '../transaction/transaction.component';
import { CarsComponent } from '../cars/cars.component';

import { DashboardComponent } from '../dashboard/dashboard.component';
import { BookServiceService } from 'src/app/service/book-service.service';
import { IBookings } from 'src/app/Interfaces/IBookings';
import { of } from 'rxjs';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { routes } from '../../app-routing.module';

describe('BookingComponent', () => {
  let component: BookingComponent;
  let fixture: ComponentFixture<BookingComponent>;
  const bookingServiceSpy = jasmine.createSpyObj('BookServiceService', ['createBooking', 'getBooking']);
  let router: Router;

  const mockBookingData: IBookings[] = [  {
    First_Name: 'Sunny',
    Last_Name: 'Kumar',
    Mobile: '9971600409',
    date: new Date(15 / 6 / 2019),
    time: '',
    duration: 5,
    car: ''
  }];
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BookingComponent, HomeComponent, DashboardComponent, 
         CarsComponent, TransactionComponent,LoginComponent ],
      
      imports: [
        BrowserModule,
        AppRoutingModule,
        BrowserAnimationsModule, HttpClientModule,
         MatToolbarModule, MatButtonModule
         , MatGridListModule, ReactiveFormsModule, FormsModule, MatInputModule, MatCardModule
         , MatFormFieldModule, MatDatepickerModule, FlexLayoutModule,Material.MatNativeDateModule,
        RouterTestingModule.withRoutes(routes)],
         providers: [
          {provide : BookServiceService,
             useValue : bookingServiceSpy }
        ],
    })
    .compileComponents();
    router = TestBed.get(Router);
    router.initialNavigation();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BookingComponent);
    component = fixture.componentInstance;
    bookingServiceSpy.getBooking.and.returnValue(of(mockBookingData));
    fixture.detectChanges();

  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it(' should get data from getbooking', async() => {
    bookingServiceSpy.getBooking.and.returnValue(of(mockBookingData));
     await component.ngOnInit();
    // expect(component.userbooking).toEqual(mockBookingData);
   });

  describe('onBooking', () => {
    let data;
    it('should get data when no error', async () => {
      bookingServiceSpy.createBooking.and.returnValue(of(mockBookingData));
      spyOn(router,'navigateByUrl').and.callFake(() => { 
        data= { status:'success'}
      })
      await component.onBooking(mockBookingData);
  
      expect(router.navigateByUrl).toHaveBeenCalled();
      expect(data).toEqual({status:'success'})

    });

  });
});
