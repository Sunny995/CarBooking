import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BookServiceService } from '../../service/book-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  private loginForm: FormGroup;
  private time: string;
  public userdata = [];
  public userBooking = [];
  public booking = [];
  constructor(private fb: FormBuilder, private route: Router, private bookService: BookServiceService) {
    setInterval(() => {
      this.time = new Date().toLocaleString();

    });
  }

  ngOnInit(): void {
    this.loginForm = this.fb.group({

      FirstName: ['', Validators.required],
      userName: ['', Validators.required],
      password: ['', Validators.required]

    });

    this.bookService.getUser()
      .subscribe(data => {
        this.userdata = data;
      });

    this.bookService.getBooking()
      .subscribe(data => {
        this.userBooking = data;
      });
  }
// check method name
  onSubmit(fname: string, name: string, pass: string): void {
    this.booking = this.userBooking.find(c => c.firstName === fname);
    if (this.booking == null) {
      this.userdata.forEach(item => {
        if (item.username === name && item.password === pass) {
          sessionStorage.setItem('fname', item.firstName);
          sessionStorage.setItem('lname', item.lastName);
          this.route.navigateByUrl('/cars');
        }
      });
    } else {
      sessionStorage.setItem('fname', fname);
      this.route.navigateByUrl('/dashboard');
    }
  }
}
