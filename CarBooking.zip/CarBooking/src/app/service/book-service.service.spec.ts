import { TestBed, getTestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import { BookServiceService } from './book-service.service';
import { AppComponent } from '../app.component';
import {  AppRoutingModule } from '../app-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { HomeComponent } from '../components/home/home.component';
import { LoginComponent } from '../components/login/login.component';
import { BookingComponent } from '../components/booking/booking.component';
import { TransactionComponent } from '../components/transaction/transaction.component';
import { CarsComponent } from '../components/cars/cars.component';
import { DashboardComponent } from '../components/dashboard/dashboard.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import * as Material from '@angular/material';
import { MatToolbarModule, MatButtonModule,
   MatGridListModule, MatInputModule, MatCardModule, MatFormFieldModule, MatDatepickerModule } from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';
import { IUsers } from '../Interfaces/IUsers';
import { IBookings } from '../Interfaces/IBookings';
import { ITransactions } from '../Interfaces/ITransactions';
import { timeInterval } from 'rxjs/operators';
import { TimeInterval } from 'rxjs/internal/operators/timeInterval';
import { ICars } from '../Interfaces/Icars';

describe('BookServiceService', () => {
  let injector: TestBed;
  let service: BookServiceService;
  let httpMock: HttpTestingController;
  const path = 'https://localhost:5001/api';

  const user = 'Deepthi';
  const mockUserData: IUsers[] = [  {
    First_Name: 'Sunny',
    Last_Name: 'Kumar',
    username: 'sunny@123',
    password: '1234'
  },
  {     First_Name: 'Deepthi',
  Last_Name: 'Reddy',
  username: 'deepthi@345',
  password: '3456'
  }];
  const mockBookingData: IBookings[] = [  {
    First_Name: 'Sunny',
    Last_Name: 'Kumar',
    Mobile: '9971600409',
    date: new Date(15 / 6 / 2019),
    time: '',
    duration: 5,
    car: ''
  }];
  const mockTransactionData: ITransactions[] = [  {
    First_Name: '',
    Last_Name: '',
    Amount: 2,
    card: ''
  },
  {     First_Name: '',
  Last_Name: '',
  Amount: 2,
  card: ''
  }];
  const mockCarsData: ICars[] = [  {
    Name: '',
    Type: '',
    Rate: 2,
    image: '',
  },
  {     Name: '',
  Type: '',
  Rate: 2,
  image: '',
  }];

  beforeEach(() => {TestBed.configureTestingModule({
    declarations: [
      AppComponent, HomeComponent,
      LoginComponent,
      BookingComponent,
      TransactionComponent,
      CarsComponent,
      DashboardComponent

    ],
    imports: [
      BrowserModule,
        AppRoutingModule,
        FormsModule, ReactiveFormsModule,
      HttpClientTestingModule,
      RouterTestingModule,
      BrowserAnimationsModule, HttpClientModule,
       MatToolbarModule, MatButtonModule
       , MatGridListModule, MatInputModule, MatCardModule
       , MatFormFieldModule, MatDatepickerModule, Material.MatNativeDateModule, FlexLayoutModule,
    ],
    providers: [BookServiceService],
  });
                    injector = getTestBed();
                    service = injector.get(BookServiceService);
                    httpMock = injector.get(HttpTestingController);
});

  it('should be created', () => { // check this error
    const service: BookServiceService = TestBed.get(BookServiceService);
    expect(service).toBeTruthy();
  });

  describe('getUser', () => {

    it('should return Users', () => {
      service.getUser().subscribe({
        next: (data) => {
          expect(data).toEqual(mockUserData);
         },
        error: (err) => { }
      });
      httpMock.expectOne({url: path + '/Users', method: 'GET' })
      .flush(mockUserData, {status: 200, statusText: 'success'});
      httpMock.verify();
    });

    it('should return error for getUsers', () => {
      service.getUser().subscribe({
        next: (data) => {
         },
        error: (err) => {
          expect(err.status).toEqual(404);
         }
      });
      httpMock.expectOne({url: path + '/Users', method: 'GET' })
      .flush('error', {status: 404, statusText: 'not found'});
      httpMock.verify();
    });

    });

  describe('getTransaction', () => {

      it('should return Transactions', () => {
        service.getTransaction().subscribe({
          next: (data) => {
            expect(data).toEqual(mockTransactionData);
           },
          error: (err) => { }
        });
        httpMock.expectOne({url: path + '/Transactions', method: 'GET' })
        .flush(mockTransactionData, {status: 200, statusText: 'success'});
        httpMock.verify();
      });

      it('should return error for getTransactions', () => {
        service.getTransaction().subscribe({
          next: (data) => {
           },
          error: (err) => {
            expect(err.status).toEqual(404);
           }
        });
        httpMock.expectOne({url: path + '/Transactions', method: 'GET' })
        .flush('error', {status: 404, statusText: 'not found'});
        httpMock.verify();
      });

      });
  describe('getCars', () => {

        it('should return CarDetails', () => {
          service.getCars().subscribe({
            next: (data) => {
              expect(data).toEqual(mockCarsData);
             },
            error: (err) => { }
          });
          httpMock.expectOne({url: path + '/CarDetails', method: 'GET' })
          .flush(mockCarsData, {status: 200, statusText: 'success'});
          httpMock.verify();
        });

        it('should return error for getCars', () => {
          service.getCars().subscribe({
            next: (data) => {
             },
            error: (err) => {
              expect(err.status).toEqual(404);
             }
          });
          httpMock.expectOne({url: path + '/CarDetails', method: 'GET' })
          .flush('error', {status: 404, statusText: 'not found'});
          httpMock.verify();
        });

        });

  describe('getBooking', () => {

          it('should return Bookings', () => {
            service.getBooking().subscribe({
              next: (data) => {
                expect(data).toEqual(mockBookingData);
               },
              error: (err) => { }
            });
            httpMock.expectOne({url: path + '/Bookings', method: 'GET' })
            .flush(mockBookingData, {status: 200, statusText: 'success'});
            httpMock.verify();
          });

          it('should return error for getBooking', () => {
            service.getBooking().subscribe({
              next: (data) => {
               },
              error: (err) => {
                expect(err.status).toEqual(404);
               }
            });
            httpMock.expectOne({url: path + '/Bookings', method: 'GET' })
            .flush('error', {status: 404, statusText: 'not found'});
            httpMock.verify();
          });

          });
  describe('createTransaction', () => {

          it('should return user created', () => {
            service.createTransaction(mockTransactionData).subscribe({
              next: (data) => {
                expect(data).toEqual(mockTransactionData);
               },
              error: (err) => { }
            });
            httpMock.expectOne({url: path + '/Transactions', method: 'POST' })
            .flush(mockTransactionData, {status: 200, statusText: 'success'});
            httpMock.verify();
          });
        });
  describe('createBooking', () => {

          it('should return Created Booking', () => {
            service.createBooking(mockBookingData).subscribe({
              next: (data) => {
                expect(data).toEqual(mockBookingData);
               },
              error: (err) => { }
            });
            httpMock.expectOne({url: path + '/Bookings', method: 'POST' })
            .flush(mockBookingData, {status: 200, statusText: 'success'});
            httpMock.verify();
          });
        });
  describe('deleteTransactions', () => {

          it('should return Transactions deleted', () => {
            service.deleteTransaction('Sunny').subscribe({
              next: (data) => {
                expect(data).toEqual(mockTransactionData);
               },
              error: (err) => { }
            });
            httpMock.expectOne({url: path + '/Transactions' + '/' + 'Sunny', method: 'DELETE' })
            .flush(mockTransactionData, {status: 200, statusText: 'success'});
            httpMock.verify();
          });

        });
  describe('deleteBooking', () => {

          it('should return Transactions deleted', () => {
            service.deleteBooking('Sunny').subscribe({
              next: (data) => {
                expect(data).toEqual(mockBookingData);
               },
              error: (err) => { }
            });
            httpMock.expectOne({url: path + '/Bookings' + '/' + 'Sunny', method: 'DELETE' })
            .flush(mockBookingData, {status: 200, statusText: 'success'});
            httpMock.verify();
          });

        });

  describe('deleteCar', () => {

          it('should return Transactions deleted', () => {
            service.deleteCar('Swift').subscribe({
              next: (data) => {
                expect(data).toEqual(mockCarsData);
               },
              error: (err) => { }
            });
            httpMock.expectOne({url: path + '/CarDetails' + '/' + 'Swift', method: 'DELETE' })
            .flush(mockCarsData, {status: 200, statusText: 'success'});
            httpMock.verify();
          });

          it('should return error when there is error', () => {
            service.deleteCar('Swift').subscribe({
              next: (data) => {
               },
              error: (err) => {
                expect(err.status).toEqual(404);
               }
            });
            httpMock.expectOne({url: path + '/CarDetails' + '/' + 'Swift', method: 'DELETE' })
            .flush('error', {status: 404, statusText: 'not found'});
            httpMock.verify();
          });

        });

});
