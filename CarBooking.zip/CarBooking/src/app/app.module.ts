import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { HomeComponent } from './components/home/home.component';
import {MatCardModule} from '@angular/material/card';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatDatepickerModule} from '@angular/material/datepicker';
import * as Material from '@angular/material';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './components/login/login.component';
import {ReactiveFormsModule, FormsModule} from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { BookingComponent } from './components/booking/booking.component';
import { TransactionComponent } from './components/transaction/transaction.component';
import { CarsComponent } from './components/cars/cars.component';
import { BookServiceService } from './service/book-service.service';
import { DashboardComponent } from './components/dashboard/dashboard.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    BookingComponent,
    TransactionComponent,
    CarsComponent,
    DashboardComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule, HttpClientModule,
     MatToolbarModule, MatButtonModule
     , MatGridListModule, ReactiveFormsModule, FormsModule, MatInputModule, MatCardModule
     , MatFormFieldModule, MatDatepickerModule, Material.MatNativeDateModule, FlexLayoutModule,


  ],
  providers: [BookServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
