import { Injectable } from '@angular/core';
import { IUsers } from '../Interfaces/IUsers';
import { Observable, throwError } from 'rxjs';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ICars } from '../Interfaces/Icars';
import { IBookings } from '../Interfaces/IBookings';
import { catchError} from 'rxjs/operators';
import { ITransactions } from '../Interfaces/ITransactions';


@Injectable({
  providedIn: 'root'
})
export class BookServiceService {
  private url = 'https://localhost:5001/api';
  constructor(private http: HttpClient) { }

  getUser(): Observable<Array<IUsers>> {
    return this.http.get<Array<IUsers>>(`${this.url}/Users`);
  }
  getBooking(): Observable<Array<IBookings>> {
    return this.http.get<Array<IBookings>>(`${this.url}/Bookings`);
  }
  getTransaction(): Observable<Array<ITransactions>> {
    return this.http.get<Array<ITransactions>>(`${this.url}/Transactions`);
  }
  createBooking(user: any) {
    return this.http.post(`${this.url}/Bookings`, user);
   }
   createTransaction(user: any) {
    return this.http.post(`${this.url}/Transactions`, user);
   }
   getCars(): Observable<Array<ICars>> {
    return this.http.get<Array<ICars>>(`${this.url}/CarDetails`);
  }

  deleteBooking(name: string): Observable<Array<IBookings>> {

    return this.http.delete<Array<IBookings>>(`${this.url}/Bookings/${name}`)
    .pipe(catchError(this.errorHandler));
     }

   deleteTransaction(name: string): Observable<Array<ITransactions>> {
     return this.http.delete<Array<ITransactions>>(`${this.url}/Transactions/${name}`)
      .pipe(catchError(this.errorHandler));
       }
   deleteCar(name: string): Observable<Array<ICars>> {
        return this.http.delete<Array<ICars>>(`${this.url}/CarDetails/${name}`)
         .pipe(catchError(this.errorHandler));
          }
errorHandler(error: HttpErrorResponse) {
  return throwError(error);
}
}