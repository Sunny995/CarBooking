import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { BookingComponent } from './components/booking/booking.component';
import { TransactionComponent } from './components/transaction/transaction.component';
import { CarsComponent } from './components/cars/cars.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';

export const routes: Routes = 
[{path: '', component: HomeComponent },
{path: 'home', component: HomeComponent },
{path: 'login', component: LoginComponent },
{path: 'booking', component: BookingComponent },
{path: 'transaction', component: TransactionComponent },
{path: 'cars', component: CarsComponent },
{path: 'dashboard', component: DashboardComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
