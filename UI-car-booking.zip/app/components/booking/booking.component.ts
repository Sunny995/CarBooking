import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BookServiceService } from '../../service/book-service.service';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {
  private CarForm: FormGroup;
  public userbooking = [];

  constructor(private fb: FormBuilder, private route: Router, private bookService: BookServiceService) { }

  ngOnInit(): void {
    this.CarForm = this.fb.group({

      mobile: ['', Validators.maxLength(10)],
      date: [{value: '', disabled: false}],
      time: ['', Validators.required],
      duration: ['', Validators.maxLength(1)],
    });
    this.getBooking();
  }

  getBooking(): void {
    this.bookService.getBooking()
    .subscribe(data =>  {
         this.userbooking = data;
         console.log(this.userbooking);
      });
  }

onBooking(d: any): void {
  this.bookService.createBooking(
   {
     firstName: sessionStorage.getItem('fname'),
     lastName: sessionStorage.getItem('lname'),
     Mobile: this.CarForm.value.mobile,
     date: this.CarForm.value.date,
     time: this.CarForm.value.time,
     duration: this.CarForm.value.duration,
     car: sessionStorage.getItem('carname'),
   })
   .subscribe(data => {

   console.log(data);
   this.route.navigateByUrl('/transaction');
   });
  sessionStorage.setItem('dura', d);
  console.log(sessionStorage.getItem('dura'));
  }


}
