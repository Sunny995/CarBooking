import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { BookServiceService } from '../../service/book-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {
  TransactionForm: FormGroup;
  private otp: number;
  private IfShow = false;
  private e: number;
  private amount: number;
  private rate: number;
  private duration: number;
  constructor(private fb: FormBuilder, private bookService: BookServiceService, private route: Router) { }

  ngOnInit() {
    this.TransactionForm = this.fb.group({
      amount: ['', Validators.required],
      card: ['', Validators.required],
      cvv: ['', [Validators.required,Validators.maxLength(3)]],
      otp: ['', Validators.required],

    });
    this.e = this.TransactionForm.value.otp;
    console.log(this.e);
    console.log('hi');
    this.rate = parseInt (sessionStorage.getItem('rate'));
    this.duration = parseInt(sessionStorage.getItem('dura'));
    this.amount = (this.rate * this.duration);

  }
  proceedToPay(): void{
    this.otp = Math.floor(1000 + Math.random() * 900000);
    alert('Enter This Otp:' + this.otp);
    this.IfShow = true;

  }
  onTransaction(otp: string): void {
    this.e = this.TransactionForm.value.otp;
    if(this.otp === this.e){
    this.bookService.createTransaction(
      {
        firstName: sessionStorage.getItem('fname'),
        lastName: sessionStorage.getItem('lname'),
        amount: this.TransactionForm.value.amount,
        card: this.TransactionForm.value.card,
      })
      .subscribe(data => {  
      console.log(data);
      this.route.navigateByUrl('/dashboard');
      });
    }
  }

}
