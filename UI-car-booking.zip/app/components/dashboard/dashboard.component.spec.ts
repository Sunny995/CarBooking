import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardComponent } from './dashboard.component';
import { CarsComponent } from '../cars/cars.component';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { HomeComponent } from '../home/home.component';
import { LoginComponent } from '../login/login.component';
import {MatCardModule} from '@angular/material/card';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import {MatToolbarModule} from '@angular/material/toolbar';
import * as Material from '@angular/material';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { AppRoutingModule } from '../../app-routing.module';
import {ReactiveFormsModule, FormsModule} from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { TransactionComponent } from '../transaction/transaction.component';
import { BookingComponent } from '../booking/booking.component';
describe('DashboardComponent', () => {
  let component: DashboardComponent;
  let fixture: ComponentFixture<DashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardComponent,CarsComponent,BookingComponent, TransactionComponent
        ,LoginComponent, HomeComponent ],
        imports :[ BrowserModule,
          AppRoutingModule,
          BrowserAnimationsModule, HttpClientModule,
           MatToolbarModule, MatButtonModule
           , MatGridListModule, ReactiveFormsModule, FormsModule, MatInputModule, MatCardModule
           , MatFormFieldModule, MatDatepickerModule, FlexLayoutModule,Material.MatNativeDateModule]
      
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
