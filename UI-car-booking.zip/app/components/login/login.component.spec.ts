import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoginComponent } from './login.component';
import { HomeComponent } from '../home/home.component';
import { DashboardComponent } from '../dashboard/dashboard.component';
import { CarsComponent } from '../cars/cars.component';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import {MatCardModule} from '@angular/material/card';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import {MatToolbarModule} from '@angular/material/toolbar';
import * as Material from '@angular/material';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { AppRoutingModule } from '../../app-routing.module';
import {ReactiveFormsModule, FormsModule} from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { TransactionComponent } from '../transaction/transaction.component';
import { BookingComponent } from '../booking/booking.component';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { routes } from '../../app-routing.module';


describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let router: Router;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoginComponent, HomeComponent, DashboardComponent, CarsComponent,
        BookingComponent, TransactionComponent
         ],
         imports : [ BrowserModule,
          AppRoutingModule,
          BrowserAnimationsModule, HttpClientModule,
           MatToolbarModule, MatButtonModule, RouterTestingModule.withRoutes(routes)
           , MatGridListModule, ReactiveFormsModule, FormsModule, MatInputModule, MatCardModule
           , MatFormFieldModule, MatDatepickerModule, FlexLayoutModule, Material.MatNativeDateModule]
    })
    .compileComponents();
    router = TestBed.get(Router);
    router.initialNavigation();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('BookCar is getting called and booking is null', () => {


    component.userBooking = [  {
      firstName: 'Sunny',
      lastName: 'Kumar',
      Mobile: '9971600409',
      date: new Date(15 / 6 / 2019),
      time: '',
      duration: 5,
      car: ''
    }];
    spyOn(router, 'navigateByUrl').and.callFake( () => {

    });
    component.userdata = [ {
      firstName: 'Sunny',
      lastName: 'Kumar',
      username: 'sunny@123',
      password: '1234'
    }, {
      firstName: 'Bharath',
      lastName: 'Kumar',
      username: 'sunny@123',
      password: '1234'
    },
    {     firstName: 'Deepthi',
    lastName: 'Reddy',
    username: 'deepthi@345',
    password: '3456'
    }];
    component.onSubmit('Sunny1', 'sunny@123', '1234');
    
    expect(router.navigateByUrl).toHaveBeenCalledWith('/cars');
    expect(router.navigateByUrl).toHaveBeenCalledTimes(2);


   });
  it('BookCar is getting called and booking is not null', () => {

    component.userBooking = [  {
      firstName: 'Sunny',
      lastName: 'Kumar',
      Mobile: '9971600409',
      date: new Date(15 / 6 / 2019),
      time: '',
      duration: 5,
      car: ''
    }];
    spyOn(router, 'navigateByUrl').and.callFake( () => {

    });
    component.onSubmit('Sunny', null, null);
    expect(component.booking).toEqual(component.userBooking[0] );
    expect(router.navigateByUrl).toHaveBeenCalledWith('/dashboard');

   });
});
