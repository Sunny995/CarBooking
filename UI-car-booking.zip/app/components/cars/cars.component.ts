import { Component, OnInit } from '@angular/core';
import { BookServiceService } from '../../service/book-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cars',
  templateUrl: './cars.component.html',
  styleUrls: ['./cars.component.css']
})
export class CarsComponent implements OnInit {
private Cars = [];
constructor(private bookService: BookServiceService, private route: Router) { }

  ngOnInit(): void {
    this.bookService.getCars()
      .subscribe(data =>  {
           this.Cars = data;
           console.log(this.Cars);
        });
  }

  bookCar(p: any): void {
    if (sessionStorage.getItem('fname') != null) {
 sessionStorage.setItem('carname', p.name);
 sessionStorage.setItem('rate', p.rate);
 this.route.navigateByUrl('/booking');
    } else {
      alert('please login to book');
    }
  }

}
