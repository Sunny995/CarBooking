export interface ICars {
    Name: string;
    Type: string;
    Rate: number;
    image: string;
}
