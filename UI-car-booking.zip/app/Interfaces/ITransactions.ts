export interface ITransactions {
    First_Name: string;
    Last_Name: string;
    Amount: number;
    card: string;
    }
