﻿using System;
using System.Collections.Generic;

namespace CarData.Models
{
    public partial class Transaction
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Amount { get; set; }
        public string Card { get; set; }
    }
}
