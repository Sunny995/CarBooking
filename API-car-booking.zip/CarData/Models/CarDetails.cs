﻿using System;
using System.Collections.Generic;

namespace CarData.Models
{
    public partial class CarDetails
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public int Rate { get; set; }
        public string Image { get; set; }
    }
}
