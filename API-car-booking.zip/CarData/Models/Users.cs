﻿using System;
using System.Collections.Generic;

namespace CarData.Models
{
    public partial class Users
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
