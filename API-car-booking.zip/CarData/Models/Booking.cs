﻿using System;
using System.Collections.Generic;

namespace CarData.Models
{
    public partial class Booking
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Mobile { get; set; }
        public DateTime Date { get; set; }
        public TimeSpan Time { get; set; }
        public double Duration { get; set; }
        public string Car { get; set; }
    }
}
