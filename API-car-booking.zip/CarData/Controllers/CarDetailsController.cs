﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CarData.Models;

namespace CarData.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarDetailsController : ControllerBase
    {
        private readonly CarContext _context;

        public CarDetailsController(CarContext context)
        {
            _context = context;
        }

        // GET: api/CarDetails
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CarDetails>>> GetCarDetails()
        {
            return await _context.CarDetails.ToListAsync();
        }

        // GET: api/CarDetails/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CarDetails>> GetCarDetails(string id)
        {
            var carDetails = await _context.CarDetails.FindAsync(id);

            if (carDetails == null)
            {
                return NotFound();
            }

            return carDetails;
        }

        // PUT: api/CarDetails/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCarDetails(string id, CarDetails carDetails)
        {
            if (id != carDetails.Name)
            {
                return BadRequest();
            }

            _context.Entry(carDetails).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CarDetailsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/CarDetails
        [HttpPost]
        public async Task<ActionResult<CarDetails>> PostCarDetails(CarDetails carDetails)
        {
            _context.CarDetails.Add(carDetails);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (CarDetailsExists(carDetails.Name))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetCarDetails", new { id = carDetails.Name }, carDetails);
        }

        // DELETE: api/CarDetails/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<CarDetails>> DeleteCarDetails(string id)
        {
            var carDetails = await _context.CarDetails.FindAsync(id);
            if (carDetails == null)
            {
                return NotFound();
            }

            _context.CarDetails.Remove(carDetails);
            await _context.SaveChangesAsync();

            return carDetails;
        }

        private bool CarDetailsExists(string id)
        {
            return _context.CarDetails.Any(e => e.Name == id);
        }
    }
}
